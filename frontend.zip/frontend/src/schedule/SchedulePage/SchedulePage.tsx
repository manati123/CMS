import React from "react";

interface Props {}

const SchedulePage = (props: Props) => {
  return <div>This is the schedule page.</div>;
};

export default SchedulePage;
