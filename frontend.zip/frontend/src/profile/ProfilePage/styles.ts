import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  h2: { fontSize: theme.typography.fontSize * 1.5 },
}));
