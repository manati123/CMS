import React from "react";

interface Props {}

const SectionsPage = (props: Props) => {
  return <div>This is the sections page.</div>;
};

export default SectionsPage;
