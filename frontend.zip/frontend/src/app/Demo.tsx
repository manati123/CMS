import { Grid } from "@material-ui/core";
import React from "react";

interface Props {}

const Demo = (props: Props) => {
  return (
    <Grid container justify="center">
      <Grid item container xs={2}>
        Acasda
      </Grid>
    </Grid>
  );
};

export default Demo;
