export type Conference = {
  conferenceId: number;
  name: string;
  proposalDeadline: number;
  reviewDeadline: number;
};
